<?
$host="localhost";
$dbuser = "root";
$dbpass = "1234";
?>